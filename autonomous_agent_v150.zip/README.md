# 🕵️‍♂️ UserLAnd Smart-Agent (The Sovereign Auditor)

**Ein autonomer, KI-gesteuerter Pentesting-Agent, der speziell für mobile Linux-Umgebungen (UserLAnd/Termux) entwickelt wurde.**

Der Smart-Agent kombiniert native Python-Sockets, heuristische Exploit-Suchen (Metasploit & Exploit-DB) und Web-Enumeration (Nikto-Lite) mit der analytischen Power moderner KIs (OpenAI GPT-4o & Google Gemini), um vollautomatische Schwachstellen-Scans durchzuführen.

---

## 🔥 Features

* **Trinity Scan-Profile:** Wähle zwischen *Recon Only* (laut & schnell), *Standard Audit* (ausgewogen) und *Ghost Sentinel* (hoher Stealth-Faktor, massiver Jitter, Gauß-verteilte Pausen).
* **Deep-Protocol Probing:** Erkennt nicht nur offene Ports, sondern sendet protokollspezifische Sonden (z.B. `EHLO`, `HELP`), um auch von restriktiven Servern Banner-Informationen zu erzwingen.
* **Nikto-Lite+ Engine:** Durchsucht Webserver (Port 80, 443, 8080) gezielt nach kritischen Pfaden (`/.env`, `/.git/config`, `/admin`, etc.) und ignoriert dabei ungültige SSL-Zertifikate.
* **Weaponization (MSF & EDB):** Führt optimierte Batch-Abfragen in der lokalen Metasploit-Datenbank aus und gleicht Funde via `searchsploit` mit der Exploit-DB ab. Abgesichert gegen Hänger im UserLAnd.
* **Universal AI Bridge:** Erkennt automatisch, ob ein OpenAI (`sk-...`) oder Gemini-Key genutzt wird, und generiert am Ende einen taktischen Audit-Bericht inkl. ausführbarer `msfconsole`-Befehle.
* **SQL-Persistence:** Sichert jeden Teilschritt atomar in einer lokalen SQLite-Datenbank (`pentest_history.db`). Keine Daten gehen bei einem Verbindungsabbruch verloren!

---

## 🛠️ Voraussetzungen & Installation

Das Skript ist für mobile Debian/Ubuntu-Umgebungen wie **UserLAnd** optimiert.

1. **Abhängigkeiten installieren:**
   ```bash
   sudo apt update
   sudo apt install python3 python3-requests git sqlite3 -y

