#!/usr/bin/env python3
import socket
import os
import sys
import time
import json
import requests
import random
import re
import subprocess
import sqlite3
import shutil
import signal
from datetime import datetime

# ======================================================================
# GLOBAL SILENT & EVASION MODE
# ======================================================================
try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except:
    pass

# ======================================================================
# KONFIGURATION v150 (PROJECT OMEGA SOVEREIGN - TOR EDITION)
# ======================================================================

# --- API-KONFIGURATION ---
API_KEY_STORAGE = "sk-..." 
MODEL_OPENAI = "gpt-4o"
MODEL_GEMINI = "gemini-2.5-flash-preview-09-2025"

DB_FILE = "pentest_history.db"
KEY_FILE = ".api_key"
REPORT_DIR = "reports"

# Evasion-Daten
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
]

PRIORITY_PORTS = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 
    80: "http", 110: "pop3", 111: "rpcbind", 135: "msrpc", 
    139: "netbios", 143: "imap", 443: "https", 445: "smb", 
    993: "imaps", 995: "pop3s", 1723: "pptp", 3306: "mysql", 
    3389: "rdp", 5900: "vnc", 8080: "http-proxy"
}

NIKTO_PATHS = [
    "/admin", "/.env", "/.git/config", "/backup", "/config.php", 
    "/wp-admin", "/login", "/phpinfo.php", "/.htaccess", "/api/v1",
    "/server-status", "/storage", "/etc/passwd", "/.ssh/id_rsa"
]

# TOR Timeouts
PROFILES = {
    "1": {"name": "RECON ONLY", "desc": "Nur Ports & Banner", "phases": [1], "delay": 0.5, "timeout": 5.0, "jitter": (0, 0.5)},
    "2": {"name": "STANDARD AUDIT", "desc": "Full Engine (Nikto+MSF+EDB)", "phases": [1, 2, 3], "delay": 2.0, "timeout": 8.0, "jitter": (1.0, 3.0)},
    "3": {"name": "GHOST SOVEREIGN", "desc": "Max Stealth & CF-Evasion", "phases": [1, 2, 3], "delay": 8.5, "timeout": 15.0, "jitter": (6.0, 30.0)}
}

state = {
    "target": "", "security_meta": {}, "useful_ports": [], "port_banners": {}, 
    "nikto_findings": [], "msf_modules": [], "exploit_db_results": [],
    "found_services": set(), "found_versions": set(),
    "past_ports": [], "new_ports": [], "lost_ports": [], "block_count": 0,
    "pre_scan_strategy": "", "executive_summary": "Lokale Analyse beendet.", "active_profile": "UNKNOWN",
    "extracted_cves": [], "past_cves": [] # NEU: Volles CVE-Gedächtnis
}

# ======================================================================
# CORE SYSTEM: NEURAL DATABASE & TOOLS
# ======================================================================

def find_binary(name):
    std = shutil.which(name)
    if std: return std
    home = os.path.expanduser("~")
    paths = [
        os.path.join(home, "exploitdb", name),
        os.path.join(home, "metasploit-framework", name),
        f"/opt/metasploit-framework/bin/{name}",
        f"/usr/local/bin/{name}"
    ]
    for p in paths:
        if os.path.exists(p): return p
    return None

def check_tool_status(name):
    return find_binary(name) is not None

def clean_api_key(raw_key):
    if not raw_key or raw_key.startswith("sk-..."): return ""
    return re.sub(r'[^a-zA-Z0-9\-_]', '', raw_key.strip())

def init_sql_db():
    try:
        if not os.path.exists(REPORT_DIR): os.makedirs(REPORT_DIR)
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute('CREATE TABLE IF NOT EXISTS scans (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, target TEXT, profile TEXT, summary TEXT, full_data TEXT)')
            # Fügt known_cves für neue Datenbanken hinzu
            conn.execute('CREATE TABLE IF NOT EXISTS intelligence (target TEXT PRIMARY KEY, last_seen TEXT, block_count INTEGER, known_ports TEXT, known_cves TEXT)')
            try:
                # Automatisches Upgrade für bestehende, alte Datenbanken
                conn.execute('ALTER TABLE intelligence ADD COLUMN known_cves TEXT')
            except: pass
            conn.commit()
    except Exception as e: print(f"\033[91m[!] DB-Initialisierungsfehler: {e}\033[0m")

def get_intelligence(target):
    try:
        with sqlite3.connect(DB_FILE) as conn:
            cur = conn.cursor()
            try:
                # Versuch mit CVEs (Neue DB)
                cur.execute("SELECT block_count, known_ports, known_cves FROM intelligence WHERE target = ?", (target,))
                row = cur.fetchone()
                if row: return {"blocks": row[0], "ports": json.loads(row[1]), "cves": json.loads(row[2]) if row[2] else []}
            except:
                # Fallback für alte DBs
                cur.execute("SELECT block_count, known_ports FROM intelligence WHERE target = ?", (target,))
                row = cur.fetchone()
                if row: return {"blocks": row[0], "ports": json.loads(row[1]), "cves": []}
    except: pass
    return {"blocks": 0, "ports": [], "cves": []}

def save_intelligence(target, current_ports, blocked=False, current_cves=None):
    if current_cves is None: current_cves = []
    try:
        past = get_intelligence(target)
        new_blocks = past["blocks"] + (1 if blocked else 0)
        updated_ports = list(set(past["ports"] + current_ports))
        updated_cves = list(set(past["cves"] + current_cves))
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute('''INSERT OR REPLACE INTO intelligence (target, last_seen, block_count, known_ports, known_cves) 
                            VALUES (?, ?, ?, ?, ?)''', (target, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), new_blocks, json.dumps(updated_ports), json.dumps(updated_cves)))
            conn.commit()
    except: pass

def sql_checkpoint():
    try:
        st_copy = state.copy()
        st_copy["found_services"] = list(state["found_services"])
        st_copy["found_versions"] = list(state["found_versions"])
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("INSERT INTO scans (timestamp, target, profile, summary, full_data) VALUES (?, ?, ?, ?, ?)", 
                         (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), state["target"], state["active_profile"], state["executive_summary"], json.dumps(st_copy)))
            conn.commit()
    except: pass

# ======================================================================
# CORE ENGINES: STEALTH & EXPLOITS
# ======================================================================

def detect_security_layers(target):
    print(f"\n\033[94m[*] Phase 0: Analyse der Verteidigungslinien (Firewall/WAF/VPN/KI)...\033[0m")
    results = {"firewall": "Standard", "vpn": "Negativ", "waf": "Nicht erkannt", "ai_defense": "Nicht erkannt"}
    try:
        ua = random.choice(USER_AGENTS)
        headers = {
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1"
        }
        response = requests.get(f"http://{target}", headers=headers, timeout=10, verify=False)
        server = response.headers.get("Server", "").lower()
        
        if "cloudflare" in server: results["waf"] = "Cloudflare"
        elif "sucuri" in server: results["waf"] = "Sucuri WAF"
        elif "akamai" in server: results["waf"] = "Akamai"
        
        vpn_headers = ["Via", "X-Forwarded-For", "X-VPN-IP", "Proxy-Connection", "Forwarded"]
        for h in vpn_headers:
            if h in response.headers:
                results["vpn"] = f"Möglicher Proxy/VPN via {h}"
                break
                
        if any(x in server for x in ["datadome", "imperva", "perimeterx", "aws-waf"]):
            results["ai_defense"] = "ML-basiertes Anti-Bot-System aktiv"
        elif "x-datadome" in response.headers or "cf-mitigated" in response.headers:
            results["ai_defense"] = "KI-Verhaltensanalyse detektiert"
        else:
            results["ai_defense"] = "Keine KI-Abwehr detektiert"
            
    except Exception:
        results["firewall"] = "Aggressives Filtering (Drop/Timeout/Tor-Block)"

    print(f"\033[92m  [+] Firewall: {results['firewall']} | WAF: {results['waf']} | VPN: {results['vpn']} | KI-Abwehr: {results['ai_defense']}\033[0m")
    return results

def socket_probe_sovereign(target, port, timeout):
    is_open, banner, is_blocked = False, "", False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            res = s.connect_ex((target, port))
            if res == 0:
                is_open = True
                try:
                    s.settimeout(3.5)
                    s.send(f"HEAD / HTTP/1.1\r\nHost: {target}\r\nUser-Agent: {random.choice(USER_AGENTS)}\r\nAccept-Language: de-DE,de;q=0.9\r\nConnection: keep-alive\r\n\r\n".encode() if port in [80, 8080, 443] else b"\r\n")
                    banner = s.recv(1024).decode(errors='ignore').strip()
                except: pass
            elif res in [110, 113, 104, 111]:
                is_blocked = True
    except: is_blocked = True
    return is_open, banner, is_blocked

def msf_tactical_batch(queries):
    msf_bin = find_binary("msfconsole")
    if not msf_bin or not queries: return []
    
    cmds = []
    for q in queries:
        clean_q = re.sub(r'[^a-zA-Z0-9.-]', ' ', q)
        cmds.append("search name:" + clean_q + " type:exploit rank:excellent")
    batch_cmd = "; ".join(cmds) + "; exit"
    
    print(f"\n\033[94m[*] Phase 3: Metasploit-Engine wird initialisiert (Batch für {len(queries)} Ziele/CVEs)...\033[0m")
    try:
        proc = subprocess.Popen([msf_bin, '-q', '-x', batch_cmd], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, preexec_fn=os.setsid)
        out, _ = proc.communicate(timeout=300)
        return list(set(re.findall(r'(exploit/[a-zA-Z0-9_/\-]+)', out)))
    except Exception as e:
        print(f"\033[91m[!] MSF-Engine Zeitüberschreitung: {e}\033[0m")
        return []

def searchsploit_audit(query):
    bin_p = find_binary("searchsploit")
    if not bin_p: return []
    try:
        print(f"\033[90m    [~] EDB-Suche: {query}...\033[0m", end="\r")
        clean_q = re.sub(r'[^a-zA-Z0-9.-]', ' ', query)
        out = subprocess.check_output([bin_p, "-j", clean_q], stderr=subprocess.DEVNULL, text=True, timeout=40)
        start = out.find('{')
        if start != -1:
            data = json.loads(out[start:])
            return [f"EDB: {r['Title']}" for r in data.get("RESULTS_EXPLOIT", [])[:2]]
    except: pass
    return []

def ask_ai_bridge(key, target, mode, context):
    is_openai = key.startswith("sk-")
    url = "https://api.openai.com/v1/chat/completions" if is_openai else f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_GEMINI}:generateContent?key={key}"
    sys_p = "Du bist ein taktischer Red-Team Lead. Antworte präzise auf Deutsch. Nenne CVE-Nummern, falls zutreffend."
    
    if mode == "strategy":
        user_p = f"Pentest-Strategie für {target}. Bekannte Ports: {context['ports']}. Blocks: {context['blocks']}. Security: {context.get('security', {})}. Gib CVEs und Angriffsvektoren."
    else:
        user_p = f"AUDIT-RESULTAT: {target}. Neue Ports: {context['new_ports']}. Scan-Daten: {json.dumps(context, default=list)}"

    if is_openai:
        h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        p = {"model": MODEL_OPENAI, "messages": [{"role": "system", "content": sys_p}, {"role": "user", "content": user_p}]}
    else:
        h = {"Content-Type": "application/json"}
        p = {"contents": [{"parts": [{"text": sys_p + "\n" + user_p}]}]}

    try:
        r = requests.post(url, headers=h, json=p, timeout=90)
        res = r.json()
        return res['choices'][0]['message']['content'].strip() if is_openai else res['candidates'][0]['content']['parts'][0]['text'].strip()
    except: return "KI-Analyse konnte nicht durchgeführt werden."

def generate_report():
    try:
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{REPORT_DIR}/OmegaReport_{state['target']}_{ts}.md"
        with open(filename, "w") as f:
            f.write(f"# 🛡️ Omega Sovereign Audit: {state['target']}\n\nZeit: {datetime.now()}\nProfil: {state['active_profile']}\n\n")
            f.write(f"## Security Layers\nFirewall: {state['security_meta'].get('firewall', 'N/A')}\nWAF: {state['security_meta'].get('waf', 'N/A')}\nVPN: {state['security_meta'].get('vpn', 'N/A')}\nKI-Abwehr: {state['security_meta'].get('ai_defense', 'N/A')}\n\n")
            f.write(f"## KI-Strategie & Extrahierte CVEs\n{state['pre_scan_strategy']}\n\n")
            if state["extracted_cves"] or state["past_cves"]:
                all_cves = list(set(state["extracted_cves"] + state["past_cves"]))
                f.write(f"**Zur Metasploit-Suche übergebene CVEs:** {', '.join(all_cves)}\n\n")
            f.write(f"## Ergebnis\n{state['executive_summary']}\n\n")
            f.write(f"## Funde\nPorts: {state['useful_ports']}\nExploits: {state['msf_modules'] + state['exploit_db_results']}")
        print(f"\n\033[92m[+] Automatischer Omega-Bericht erstellt: {filename}\033[0m")
    except: pass

# ======================================================================
# UI & WORKFLOW
# ======================================================================

def display_banner(key):
    os.system('clear')
    tools = {
        "AI": "\033[92mOK\033[0m" if key else "\033[91mNO\033[0m",
        "MSF": "\033[92mOK\033[0m" if check_tool_status("msfconsole") else "\033[91mNO\033[0m",
        "EDB": "\033[92mOK\033[0m" if check_tool_status("searchsploit") else "\033[91mNO\033[0m",
        "TOR": "\033[92mAKTIV\033[0m" if "TOR_ROUTING" in os.environ else "\033[93mINAKTIV\033[0m"
    }
    # HIER IST DIE BANNER-ÄNDERUNG: "PROJECT OMEGA SOVEREIGN v150"
    print("\033[96m   ____  __  ____________ ___ \n  / __ \\/  |/  / ____/ __ \\/   | \n / / / / /|_/ / __/ / / _  / /| | \n/ /_/ / /  / / /___/ /_/ / ___ | \n\\____/_/  /_/_____/\\____/_/  |_| \n\n    PROJECT OMEGA SOVEREIGN v150\n        Status: Ultimate Evasion Mode\033[0m")
    print("\033[91m" + "="*70 + "\033[0m")
    print(f"  AI: {tools['AI']} | MSF: {tools['MSF']} | EDB: {tools['EDB']} | GHOST-ROUTING (TOR): {tools['TOR']}")
    print("\033[91m" + "="*70 + "\033[0m")
    for k, p in PROFILES.items(): print(f"  [{k}] {p['name']}: {p['desc']}")
    print("\033[91m" + "="*70 + "\033[0m")

def main():
    init_sql_db()
    
    current_key = clean_api_key(API_KEY_STORAGE)
    if not current_key and os.path.exists(KEY_FILE):
        with open(KEY_FILE, "r") as f: current_key = clean_api_key(f.read())
    
    display_banner(current_key)
    target = input("\033[93mZiel-Host: \033[0m").strip()
    if not target: return
    state["target"] = target.replace("http://", "").replace("https://", "").strip("/")

    state["security_meta"] = detect_security_layers(state["target"])

    intel = get_intelligence(state["target"])
    state["past_ports"], state["block_count"], state["past_cves"] = intel["ports"], intel["blocks"], intel["cves"]
    intel["security"] = state["security_meta"]

    if state["past_ports"] or state["past_cves"]: 
        print(f"\033[94m[*] Gedächtnis aktiv: {len(state['past_ports'])} Ports und {len(state['past_cves'])} CVEs aus Vor-Scans bekannt.\033[0m")
    
    if current_key and input("\033[96mKI-Briefing (Strategie & CVEs) einholen? (j/n): \033[0m").lower() == 'j':
        state["pre_scan_strategy"] = ask_ai_bridge(current_key, state["target"], "strategy", intel)
        print(f"\n\033[97m=== KI STRATEGIE ===\n{state['pre_scan_strategy']}\n====================\033[0m\n")
        
        cves = re.findall(r'CVE-\d{4}-\d{4,7}', state["pre_scan_strategy"], re.IGNORECASE)
        if cves:
            state["extracted_cves"] = list(set([c.upper() for c in cves]))
            print(f"\033[93m[*] KI hat neue CVEs markiert: {', '.join(state['extracted_cves'])}\033[0m")

    def_choice = "3" if state["block_count"] > 0 else "2"
    choice = input(f"\033[93mWähle Profil (1-3) [Vorschlag: {def_choice}]: \033[0m").strip() or def_choice
    profile = PROFILES.get(choice, PROFILES[def_choice])
    state["active_profile"] = profile["name"]

    try:
        # Phase 1: Ports
        p_list = list(PRIORITY_PORTS.keys()); random.shuffle(p_list)
        blocked_now = False
        for p in p_list:
            print(f"\033[90m  > Prüfe Port {p} ({PRIORITY_PORTS[p]})...\033[0m", end="\r")
            ok, banner, blocked = socket_probe_sovereign(state["target"], p, profile["timeout"])
            if blocked: blocked_now = True
            if ok:
                state["useful_ports"].append(str(p))
                state["found_services"].add(PRIORITY_PORTS[p])
                if banner:
                    state["port_banners"][p] = banner
                    v_match = re.search(r'([A-Za-z0-9\-\.]+/[0-9\.]+)', banner)
                    if v_match: state["found_versions"].add(v_match.group(1))
                    print(f"\033[92m[+] Port {p} OFFEN: {banner[:40]}\033[0m")
                else: print(f"\033[92m[+] Port {p} OFFEN\033[0m")
            time.sleep(profile["delay"] + random.uniform(profile["jitter"][0], profile["jitter"][1]))
        
        state["new_ports"] = [p for p in state["useful_ports"] if p not in state["past_ports"]]
        if state["new_ports"]: print(f"\033[93m[!] Gedächtnis-Update: Neue Angriffsfläche entdeckt: {state['new_ports']}\033[0m")
        
        # Speichert Ports UND die gerade extrahierten CVEs ins Gedächtnis
        save_intelligence(state["target"], state["useful_ports"], blocked=blocked_now, current_cves=state["extracted_cves"])
        sql_checkpoint()

        # Phase 2: Web
        if 2 in profile["phases"] and state["useful_ports"]:
            print(f"\n\033[94m[*] Phase 2: Web-Audit (Cloudflare Bypass aktiv)...\033[0m")
            for wp in [80, 443, 8080]:
                if str(wp) in state["useful_ports"]:
                    base = f"http://{state['target']}:{wp}" if wp != 443 else f"https://{state['target']}"
                    for path in NIKTO_PATHS:
                        try:
                            headers = {
                                "User-Agent": random.choice(USER_AGENTS),
                                "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7"
                            }
                            r = requests.head(base+path, timeout=10, verify=False, headers=headers)
                            if r.status_code < 400:
                                state["nikto_findings"].append(f"Port {wp}: {path} ({r.status_code})")
                                print(f"\033[92m  [!] Web-Fund: {path} ({r.status_code})\033[0m")
                        except: pass
            sql_checkpoint()

        # Phase 3: Exploits (mit historischen und neuen KI CVEs!)
        if 3 in profile["phases"]:
            print(f"\n\033[94m[*] Phase 3: Exploit-Suche (Searchsploit & MSF)...\033[0m")
            for q in list(state["found_services"]): state["exploit_db_results"].extend(searchsploit_audit(q))
            
            # SUCHT NACH: Gefundenen Diensten + Versionen + Neuen CVEs + ALTEN CVEs aus dem Gedächtnis
            queries = list(state["found_services"]) + list(state["found_versions"]) + list(set(state["extracted_cves"] + state["past_cves"]))
            state["msf_modules"] = msf_tactical_batch(queries)
            sql_checkpoint()

        if current_key and input("\n\033[96mAbschließende KI-Analyse generieren? (j/n): \033[0m").lower() == 'j':
            state["executive_summary"] = ask_ai_bridge(current_key, state["target"], "audit", state)
            print(f"\n\033[97m{state['executive_summary']}\033[0m\n")
            sql_checkpoint()

        generate_report()

    except KeyboardInterrupt:
        print("\n\033[91m[!] Abbruch durch Nutzer. Checkpoint wird erstellt...\033[0m")
        sql_checkpoint(); generate_report(); sys.exit(0)

if __name__ == "__main__":
    main()
