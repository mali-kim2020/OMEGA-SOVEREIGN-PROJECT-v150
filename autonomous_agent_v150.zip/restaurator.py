#!/bin/bash

# ======================================================================
# UserLAnd Environment Restore Script v1.0
# Dieses Script installiert alle Abhängigkeiten für den Smart-Agent
# ======================================================================

echo -e "\033[96m[*] Starte Wiederherstellung der Arbeitsumgebung...\033[0m"

# 1. System Updates
echo -e "\033[94m[1/4] Aktualisiere Systempakete...\033[0m"
sudo apt update && sudo apt upgrade -y

# 2. Tools installieren
echo -e "\033[94m[2/4] Installiere Pentest-Tools (MSF, EDB, Python)...\033[0m"
sudo apt install -y python3 python3-pip git metasploit-framework exploitdb

# 3. Python Libraries
echo -e "\033[94m[3/4] Installiere Python-Abhängigkeiten...\033[0m"
pip3 install requests urllib3

# 4. Verzeichnisse vorbereiten
echo -e "\033[94m[4/4] Erstelle Ordnerstruktur...\033[0m"
mkdir -p reports backups

echo -e "\033[92m[SUCCESS] Umgebung ist bereit!\033[0m"
echo -e "\033[93m[TIPP] Kopiere nun dein Backup (.zip) hierher und entpacke es.\033[0m"
